plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.techtycoon.game"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.techtycoon.game"
        minSdk = 26
        targetSdk = 35
        versionCode = 8
        versionName = "3.0.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
